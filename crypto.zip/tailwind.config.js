module.exports = {
    content: [
      "./index.html",
      "./src/**/*.{js,ts,jsx,tsx}", // This covers all your component files
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  };
  